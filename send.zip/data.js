  const data = [
            {
                title: "Premium Plumbing",
                desc: "Top-tier plumbing pipes and fittings solutions for your household needs.",
                img: "https://www.supreme.co.in/uploads/images/ndUCyUjcaUlIehcBdq6i3DuF44qnJALVsQHO6U3G.jpg",
                link: "products/pipes.html",
                color: "from-blue-500 to-cyan-500"
            },
            {
                title: "Smart Water Tanks",
                desc: "Revolutionary plastic water storage solutions including advanced overhead and underground systems for diverse residential needs.",
                img: "https://www.supreme.co.in/uploads/images/NrPGrXMF7Am8aO7R8TMbjiqJBy26FgLxtXtZnEw2.jpg",
                link: "products/tanks.html",
                color: "from-green-500 to-teal-500"
            },
            {
                title: "Luxury Bath Fittings",
                desc: "Quality-tested chrome and plastic bath fittings cater to all your bathroom accessory needs.",
                img: "https://www.supreme.co.in/uploads/images/XpVHbHmFSyXMWgAx3v88EsUWD6jgSjjTeZvt5i6K.jpg",
                link: "products/bath.html",
                color: "from-purple-500 to-pink-500"
            }
        ];
        const plants = [
            {
                img: "https://www.supreme.co.in/dist/img/pipes/plant-1.jpg",
                title: "Main Manufacturing Hub",
                desc: "Our flagship facility equipped with cutting-edge technology"
            },
            {
                img: "https://www.supreme.co.in/dist/img/pipes/plant-2.jpg",
                title: "Quality Control Center",
                desc: "Advanced testing and quality assurance facility"
            },
            {
                img: "https://www.supreme.co.in/dist/img/pipes/plant-3.jpg",
                title: "Innovation Lab",
                desc: "Research and development center for next-gen products"
            }
        ];